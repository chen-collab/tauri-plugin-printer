/** 打印机信息 */
export interface PrinterInfo {
    name: string;
    driverName: string;
    jobCount: number;
    printProcessor: string;
    portName: string;
    shareName: string;
    computerName: string;
    printerStatus: string[];
    shared: boolean;
    printerType: number;
    priority: number;
}
/** 打印任务信息 */
export interface JobInfo {
    documentName: string;
    id: number;
    totalPages: number;
    position: number;
    size: number;
    submittedTime: string;
    userName: string;
    pagesPrinted: number;
    jobTime: number;
    computerName: string;
    datatype: string;
    printerName: string;
    priority: number;
    jobStatus: string[];
}
/** PDF 打印选项 */
export interface PrintPdfOptions {
    id: string;
    path: string;
    printerSetting: string;
    removeAfterPrint: boolean;
}
/** HTML 打印选项 */
export interface PrintHtmlOptions {
    html: string;
    printerId?: string;
    printSettings?: string;
    removeAfterPrint?: boolean;
    /** 页面大小：A4, A5, Letter 等 */
    pageSize?: string;
    /** 自定义纸张宽度（mm），与 pageSize 二选一，有自定义宽高时优先 */
    pageWidth?: number;
    /** 自定义纸张高度（mm） */
    pageHeight?: number;
    /** 方向：Portrait, Landscape */
    orientation?: string;
    margin?: PrintMargin;
    quality?: number;
    grayscale?: boolean;
    copies?: number;
}
/** 打印边距 */
export interface PrintMargin {
    top: number;
    bottom: number;
    left: number;
    right: number;
    unit: string;
}
/** 测试连接 */
export declare function ping(value: string): Promise<string | null>;
/** 获取所有打印机 */
export declare function getPrinters(): Promise<PrinterInfo[]>;
/** 按名称获取打印机 */
export declare function getPrinterByName(printerName: string): Promise<PrinterInfo>;
/** 打印 PDF 文件 */
export declare function printPdf(options: PrintPdfOptions): Promise<string>;
/** 打印 HTML 内容 */
export declare function printHtml(options: PrintHtmlOptions): Promise<string>;
/** 获取打印任务列表 */
export declare function getJobs(printerName: string): Promise<JobInfo[]>;
/** 按 ID 获取打印任务 */
export declare function getJobById(printerName: string, jobId: string): Promise<JobInfo>;
/** 恢复打印任务 */
export declare function resumeJob(printerName: string, jobId: string): Promise<void>;
/** 重启打印任务 */
export declare function restartJob(printerName: string, jobId: string): Promise<void>;
/** 暂停打印任务 */
export declare function pauseJob(printerName: string, jobId: string): Promise<void>;
/** 删除打印任务 */
export declare function removeJob(printerName: string, jobId: string): Promise<void>;
/** 创建临时文件 */
export declare function createTempFile(base64Data: string, filename: string): Promise<string>;
/** 删除临时文件 */
export declare function removeTempFile(filename: string): Promise<boolean>;
