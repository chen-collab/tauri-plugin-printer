'use strict';

var core = require('@tauri-apps/api/core');

// ========== API 函数 ==========
/** 测试连接 */
async function ping(value) {
    return await core.invoke('plugin:printer-v2|ping', {
        payload: { value },
    }).then((r) => (r.value ? r.value : null));
}
/** 获取所有打印机 */
async function getPrinters() {
    return await core.invoke('plugin:printer-v2|get_printers');
}
/** 按名称获取打印机 */
async function getPrinterByName(printerName) {
    return await core.invoke('plugin:printer-v2|get_printers_by_name', {
        printername: printerName,
    });
}
/** 打印 PDF 文件 */
async function printPdf(options) {
    return await core.invoke('plugin:printer-v2|print_pdf', {
        id: options.id,
        path: options.path,
        printerSetting: options.printerSetting,
        removeAfterPrint: options.removeAfterPrint,
    });
}
/** 打印 HTML 内容 */
async function printHtml(options) {
    return await core.invoke('plugin:printer-v2|print_html', {
        options: options,
    });
}
/** 获取打印任务列表 */
async function getJobs(printerName) {
    return await core.invoke('plugin:printer-v2|get_jobs', {
        printername: printerName,
    });
}
/** 按 ID 获取打印任务 */
async function getJobById(printerName, jobId) {
    return await core.invoke('plugin:printer-v2|get_jobs_by_id', {
        printername: printerName,
        jobid: jobId,
    });
}
/** 恢复打印任务 */
async function resumeJob(printerName, jobId) {
    return await core.invoke('plugin:printer-v2|resume_job', {
        printername: printerName,
        jobid: jobId,
    });
}
/** 重启打印任务 */
async function restartJob(printerName, jobId) {
    return await core.invoke('plugin:printer-v2|restart_job', {
        printername: printerName,
        jobid: jobId,
    });
}
/** 暂停打印任务 */
async function pauseJob(printerName, jobId) {
    return await core.invoke('plugin:printer-v2|pause_job', {
        printername: printerName,
        jobid: jobId,
    });
}
/** 删除打印任务 */
async function removeJob(printerName, jobId) {
    return await core.invoke('plugin:printer-v2|remove_job', {
        printername: printerName,
        jobid: jobId,
    });
}
/** 创建临时文件 */
async function createTempFile(base64Data, filename) {
    return await core.invoke('plugin:printer-v2|create_temp_file', {
        bufferData: base64Data,
        filename: filename,
    });
}
/** 删除临时文件 */
async function removeTempFile(filename) {
    return await core.invoke('plugin:printer-v2|remove_temp_file', {
        filename: filename,
    });
}

exports.createTempFile = createTempFile;
exports.getJobById = getJobById;
exports.getJobs = getJobs;
exports.getPrinterByName = getPrinterByName;
exports.getPrinters = getPrinters;
exports.pauseJob = pauseJob;
exports.ping = ping;
exports.printHtml = printHtml;
exports.printPdf = printPdf;
exports.removeJob = removeJob;
exports.removeTempFile = removeTempFile;
exports.restartJob = restartJob;
exports.resumeJob = resumeJob;
